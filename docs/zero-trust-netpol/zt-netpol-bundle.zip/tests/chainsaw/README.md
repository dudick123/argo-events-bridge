# Chainsaw regression suite

Prereqs: kind, cilium CLI, helm, kubectl, chainsaw. Bring the harness up with
`scripts/bootstrap-test-cluster.sh`, then run:

```
chainsaw test tests/chainsaw
```

| Test | Verifies |
|---|---|
| `tenant-baseline-generate` | Namespace with the tenant label receives all 7 T1 policies with expected content; deleting one triggers Kyverno `synchronize` re-creation |
| `cnp-guardrails-block` | Admission rejects unbounded CIDRs, `world`/`all`/`cluster` entities, multi-`specs` documents, and missing `spec.description` |
| `cnp-guardrails-allow` | A correctly scoped policy (named peers, `toFQDNs`, description) is admitted -- guards against over-blocking |
| `baseline-protection` | UPDATE/DELETE of a generated `zt-*` baseline policy is denied for non-platform identities |

Notes:
- `baseline-protection` must run with a kubeconfig identity that is NOT in the
  `platform-network-admins` group (the default kind admin qualifies).
- Test namespaces are cleaned up by chainsaw; namespace cascade-deletion of
  protected CNPs works because the protection policy excludes the kube-system
  namespace-controller and garbage-collector service accounts.
- The suite runs in the policy repo's ADO pipeline on every PR (same pattern
  as the Kyverno enforcement rollout harness).
