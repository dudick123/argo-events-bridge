#!/usr/bin/env bash
# Bootstraps a local kind cluster with Cilium + Kyverno and installs the
# policy bundle, ready for `chainsaw test tests/chainsaw`. Mirrors the ADO
# CI harness used for the Kyverno rollout repo.
set -euo pipefail

CLUSTER_NAME="${CLUSTER_NAME:-zt-netpol}"
CILIUM_VERSION="${CILIUM_VERSION:-1.16.5}"   # must be >= 1.15 for enableDefaultDeny
KYVERNO_VERSION="${KYVERNO_VERSION:-3.3.4}"

kind create cluster --name "${CLUSTER_NAME}" --config - <<KIND
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
networking:
  disableDefaultCNI: true   # Cilium is the CNI
  kubeProxyMode: none
nodes:
  - role: control-plane
  - role: worker
KIND

cilium install --version "${CILIUM_VERSION}" \
  --set kubeProxyReplacement=true \
  --set policyEnforcementMode=default
cilium status --wait

helm repo add kyverno https://kyverno.github.io/kyverno --force-update
helm install kyverno kyverno/kyverno -n kyverno --create-namespace \
  --version "${KYVERNO_VERSION}" --wait

# RBAC must land before the generate policy so the background controller can
# create CNPs immediately.
kubectl apply -f rbac/
kubectl apply -k policies/kyverno/
kubectl apply -k policies/cilium/clusterwide/

echo "Ready. Run: chainsaw test tests/chainsaw"
