# Zero-Trust Network Segmentation (PRD-2026-NETPOL-ZT-001)

Default-deny, identity-based east-west segmentation for the multi-tenant AKS
GitOps platform: Cilium network policies delivered per tenant namespace by a
Kyverno generate policy, tenant self-serve constrained by Kyverno guardrails,
and the whole suite regression-tested with Chainsaw.

## Layout

```
docs/
  PRD-2026-NETPOL-ZT-001.md        PRD with embedded architecture diagram
  architecture.mermaid             standalone diagram
policies/
  cilium/clusterwide/              T0 -- CCNPs (Cilium health, kube-dns)
  cilium/tenant-baseline/          T1 -- reference copies of the generated set
  cilium/tenant-optional/          T2 -- opt-in templates for tenants
  kyverno/                         generate + guardrails + protection
rbac/                              aggregated ClusterRoles for Kyverno controllers
tests/chainsaw/                    CI regression suite (see its README)
scripts/bootstrap-test-cluster.sh  kind + Cilium + Kyverno harness
```

## Policy tiers

| Tier | Kind | Owner | Delivery |
|---|---|---|---|
| T0 cluster | CiliumClusterwideNetworkPolicy | Platform | ArgoCD app-of-apps |
| T1 tenant baseline (`zt-*`) | CiliumNetworkPolicy | Platform via Kyverno generate, `synchronize: true` | Admission-time, tamper-protected |
| T2 tenant self-serve | CiliumNetworkPolicy | Tenant config repo | ArgoCD, validated by guardrails |

## Before merging -- placeholders to adjust

- `platform.example.com/tenant` -- tenant namespace label key (confirm against
  the Copier onboarding `provisioning.yaml` conventions)
- `platform-network-admins` -- break-glass Entra ID group in the guardrail and
  protection policies
- `akuity/argocd-agent` -- the SA that applies the T0 bundle
- `envoy-gateway-system`, `datadog`, `confluent` -- namespace names and Datadog
  agent labels
- Verify Cilium >= 1.15 on all clusters (`enableDefaultDeny`)

## Rollout (summary)

Audit-first (`enableDefaultDeny: false` overlay + Hubble->Datadog would-be-drop
monitoring), tenant education with self-serve templates, then per-wave
enforcement dev -> nonprod -> prod by tenant tier. Full plan in the PRD.

## Important invariants

- The T1 data inside `policies/kyverno/generate-tenant-network-baseline.yaml`
  is the source of truth applied to clusters; `policies/cilium/tenant-baseline/`
  documents it for review/diffing. Change both in the same PR (Chainsaw
  asserts key fields and will catch divergence).
- Tenant config-repo templates must NOT render `zt-*` policies; ArgoCD never
  manages generated resources, so no `ignoreDifferences` changes are needed.
- Cilium enforces both directions independently: every cross-boundary allow
  needs a sender-side egress rule AND a receiver-side ingress rule.
